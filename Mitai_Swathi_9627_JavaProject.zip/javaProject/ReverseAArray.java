package javaProject;

public class ReverseAArray {

	public static void main(String[] args) 
	{
		Integer[] intArray = {1,2,3,4,5,6};
		
		//print array starting from first element
		System.out.println("Original Array: ");
		for(int i=0;i<intArray.length;i++)
		{
			System.out.println(intArray[i]+ " ");
		}
		
		//print array starting from last element
		System.out.println("Original array in reverse order: ");
		for(int i=intArray.length-1;i>=0;i--)
		{
			System.out.println(intArray[i]+ " ");
		}

	}

}
