package javaProject;

public interface Drawable
{

}
