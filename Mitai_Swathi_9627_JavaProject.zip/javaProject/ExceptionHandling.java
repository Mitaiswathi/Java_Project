package javaProject;

public class ExceptionHandling {

	public static void main(String[] args)
	{
			try 
			{
				System.out.println("In try block");
				int a[] = new int[5];
				a[4] = 20 / 2; 
				a[2] = 50 / 0;
				System.out.println("try block is executed");
			} 
			catch (ArithmeticException e)
			{
				System.out.println("Arithmet Exception : Cannot divide a number by 0");
			} 
			catch (ArrayIndexOutOfBoundsException e) 
			{
				System.out.println("ArrayIndexOutOfBoundException");
			}
			catch (Exception e)
			{
				System.out.println("Exception occured");
			} 
			finally 
			{
				System.out.println("This code always be excuted");
			}
			System.out.println("Code Execution is competed");

		}


	}


