package javaProject;

public class HybridInheritance 
{
	public static void main(String[] args)
	{
		Chair c= new Chair();
		c.show4();
		c.show2();
		c.show1();
		
		Table t= new Table();
		t.show3();
		t.show2();
		t.show1();
	}
}
class Tree
{
	public void show1()
	 {
		 System.out.println("Iam a tree");
	 }
}
class Wood extends Tree
{
	public void show2()
	 {
		 System.out.println("wood extends tree");
	 }
}
class Table extends Wood
{
	public void show3()
	 {
		 System.out.println("Table is made of wood");
	 }
}
class Chair extends Wood
{
	 public void show4()
	 {
		 System.out.println("Chair is made of wood");
	 }
}
