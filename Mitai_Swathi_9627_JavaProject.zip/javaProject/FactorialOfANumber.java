package javaProject;

import java.util.Scanner;

public class FactorialOfANumber {

	public static void main(String[] args)
	{
      int i,fact=1;
      System.out.println("Enter a number:");
      Scanner s= new Scanner(System.in);
      int n=s.nextInt();
      for(i=1; i<=n; i++)
      {
    	  fact=fact*i;
      }
      System.out.println("Factorial of a number is: "+fact);
	}
}
