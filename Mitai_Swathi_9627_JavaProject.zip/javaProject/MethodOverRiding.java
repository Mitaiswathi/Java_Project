package javaProject;

public class MethodOverRiding
{
	public static void main(String[] args) 
	{
		Dog d=new Dog();
		d.eating();
        Human h=new Human();
        h.eating();
	}
}
class Animal
{
	public void eating()
	{
		System.out.println("Animal eats food");
	}
}
class Dog extends Animal
{
	public void eating()
	{
		System.out.println("Dog eats biscuit");
	}
}
class Human extends Animal
{
	public void eating()
	{
		System.out.println("Human eats Rice");
		System.out.println("Human loves panipuri too");
	}
}