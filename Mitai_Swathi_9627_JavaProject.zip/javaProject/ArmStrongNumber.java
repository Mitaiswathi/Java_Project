package javaProject;

import java.util.Scanner;

public class ArmStrongNumber {

	public static void main(String[] args)
	{
		Scanner s= new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=s.nextInt();
		int sum=0;
		int temp=n;
		int r;
		while(n>0)
		{
		r=n%10;
		sum=sum+(r*r*r);
		n=n/10;
		}
		if(temp==sum)
		{
		System.out.println("Armstrong Number");
		}
		else
		{
		System.out.println("Not an Armstrong Number");
	    }
	}
}
