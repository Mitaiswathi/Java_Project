package javaProject;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args)
	{
		System.out.println("Enter a number");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		if(n<=1)
		{
			System.out.println("It is not a Prime number");
		}
		else if(n%2!=0)
		{
			System.out.println("It is a Prime number");
		}
		else
		{
			System.out.println("Not a prime number");
		}
	}

}
