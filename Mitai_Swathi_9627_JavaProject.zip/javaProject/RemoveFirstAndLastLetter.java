package javaProject;

import java.util.Scanner;

public class RemoveFirstAndLastLetter {

	public static void main(String[] args)
	{
		System.out.println("Enter a string:");
		Scanner sc=new Scanner(System.in);
		String st=sc.next();
		System.out.println(removeFirstAndLast(st));

	}
	public static String removeFirstAndLast(String str)
	{
		//Removing first and last character of a string using substring() method
		str=str.substring(1,str.length()-1);
		return str;
	}

}
